import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submittedforms',
  templateUrl: './submittedforms.component.html',
  styleUrls: ['./submittedforms.component.css']
})
export class SubmittedformsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { LogindialogComponent } from './../logindialog/logindialog.component';
import { Component, OnInit, VERSION, Input } from '@angular/core';
import { Validators,  FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';




@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit  {
  name:string;
  inboundClick = true;
  timeLeft: number = 60;
  interval;


actionMethod(event: any) {
    event.target.disabled = true;
    
}
constructor( public dialog: MatDialog) {
  
}

  openDialog(){
    this.dialog.open(LogindialogComponent
    
      );
  }
  ngOnInit() {
  }

  
  startTimer() {
    this.interval = setInterval(() => {
      if(this.timeLeft > 0) {
        this.timeLeft--;
        }
    },1500)
  }
  resetTimer() {
    this.interval = setInterval(() => {
      this.timeLeft = 60;
      
    },1500)
  }     
 
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      
    }
    return true;

  }

  otp = new FormControl('required',[Validators.required]);
  number = new FormControl('required',[Validators.required]);
  


  
  }
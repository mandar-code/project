import { ReactiveFormsModule, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import * as _ from 'lodash';
interface examination1 {
  value: string;
  viewValue: string;}
interface examination2 {
  value: string;
  viewValue: string;}
interface examination3 {
  value: string;
  viewValue: string;}
interface examination4 {
  value: string;
  viewValue: string;}




@Component({
  selector: 'admissionforms',
  templateUrl: './admissionforms.component.html',
  styleUrls: ['./admissionforms.component.css']
})
export class AdmissionformsComponent implements OnInit {
  exam1: examination1[] = [
    {value: 'SSC', viewValue: 'SSC'},];
  exam2: examination2[] = [
    {value: 'HSC', viewValue: 'HSC'},];
  exam3: examination3[] = [
    {value: 'Sem1', viewValue: 'Sem1'},
    {value: 'Sem3', viewValue: 'Sem3'},];
  exam4: examination4[] = [
    {value: 'Sem2', viewValue: 'Sem2'},
    {value: 'Sem4', viewValue: 'Sem4'},];

  ///////////////tab change index
  public tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    this.selectedIndex = tabChangeEvent.index;
}
public nextStep() {
    this.selectedIndex += 1;
}
public prevStep() {
    this.selectedIndex -= 1;}

    ////object s
  selectedIndex: number;
  isChecked: boolean;
  form: any;

  imageError: any;
  cardImageBase64: any;
  isImageSaved: boolean;

  imageError1: any;
  cardImage1Base64: any;
  isImage1Saved: boolean;

  signError:any;
  cardSignBase64:any;
  isSignSaved:boolean;

//same address
checkValue(e) { {
  if (e.target.checked) {
    const dVal = this.form.controls["ca"].value;
    this.form.controls["pa"].setValue(dVal);}
  else {
    this.form.controls["pa"].setValue('');
 `` }}}




///////constructor
constructor(private fb: FormBuilder,) {
this.isChecked = false;
this.form = this.fb.group({
ca: [''],pa: [''],
});}

//////ngonit
ngOnInit() {this.selectedIndex=0;}
 
fileChangeEvent2(fileInput: any) {
this.imageError = null;
if (fileInput.target.files && fileInput.target.files[0]) {
// Size Filter Bytes
const max_size = 1000000;
const allowed_types =  ['application/pdf', 'image/jpg','image/jpeg'];
const min_size = 100000;
  
if (fileInput.target.files[0].size > max_size) {
this.imageError ='* The size of the file should fall between 400KB to 1000KB';
return false;}
if(fileInput.target.files[0].size < min_size){
this.imageError = '* The size of the file should fall between 400KB to 1000KB';
return false;}
if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
this.imageError = '* The file format should ( JPG | JPEG | PDF )';
return false;}    
}
}
/////////////////for image1 
fileChangeEvent(fileInput: any) {
this.imageError1 = null;
if (fileInput.target.files && fileInput.target.files[0]) {
 // Size Filter Bytes
const max_size = 20000;
const allowed_types = ['image/jpg', 'image/jpeg'];
let max_height = 210;
let max_width = 160;
const min_size= 5000;
        
if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
this.imageError1 = '* Photograph Format should be JPEG';
return false;}
if ( fileInput.target.files[0].size > max_size) {
this.imageError1 = 'The size of the photograph should fall between 5KB to 20KB.';
return false;}
if ( fileInput.target.files[0].size < min_size) {
this.imageError1 = 'The size of the photograph should fall between 5KB to 20KB.';
return false;}
        
const reader = new FileReader();
reader.onload = (e: any) => {
const image = new Image();
image.src = e.target.result;
image.onload = rs => {
const img_height = rs.currentTarget['height'];
const img_width = rs.currentTarget['width'];
              
if (img_height < max_height) {
this.imageError1=' * The height of the photograph should fall between 200 to 212 pixels.'+
'Height of your photo is'+img_height + 'Pixel.';
return false;} 
if (img_width < max_width){
this.imageError1=' * The width of the photograph should be 160 pixels.'+'Width of your photo is' +
img_width +'Pixel.';
return false;}
                
if (img_height > max_height){              
this.imageError1=' * The height of the photograph should fall between 200 to 212 pixels.'+'Height of your photo is'+
img_height + 'Pixel.'; 
return false;}                 

if (img_width > max_width){
this.imageError1=' * The width of the photograph should be 160 pixels.'+
'Width of your photo is'+
 img_width +'Pixel.';
return false;}
else {
const imgBase64Path = e.target.result;
 this.cardImage1Base64 = imgBase64Path;
this.isImage1Saved = true;
}                
};
};
reader.readAsDataURL(fileInput.target.files[0]);
}
}
   
 /////////////////for sign
fileChangeEvent1(fileInput1: any) {
this.signError = null;
if (fileInput1.target.files && fileInput1.target.files[0]) {
// Size Filter Bytes
const max_size = 20000;
const allowed_types = ['image/jpg', 'image/jpeg'];
let max_height = 210;
let max_width = 160;
const min_size= 5000;
        
if (!_.includes(allowed_types, fileInput1.target.files[0].type)) {
this.signError = '* Photograph Format should be JPEG';
return false;}
if ( fileInput1.target.files[0].size > max_size) {
this.signError = 'The size of the photograph should fall between 5KB to 20KB';
return false;}
if ( fileInput1.target.files[0].size < min_size) {
this.signError = 'The size of the photograph should fall between 5KB to 20KB.';
return false;}

const reader1 = new FileReader();
reader1.onload = (e: any) => {
const image1 = new Image();
image1.src = e.target.result;
image1.onload = rs => {
const img_height = rs.currentTarget['height'];
const img_width = rs.currentTarget['width'];
                
if (img_height < max_height) {
this.signError=' * The height of the photograph should fall between 200 to 212 pixels.'+
'Height of your photo is'+
img_height + 'Pixel.';
return false;}                 
if (img_width < max_width){
this.signError=' * The width of the photograph should be 160 pixels.'+
'Width of your photo is' +
img_width +'Pixel.';
return false;}
if (img_height > max_height){
this.signError=' * The height of the photograph should fall between 200 to 212 pixels.'+
'Height of your photo is'+img_height + 'Pixel.';
return false;}
if (img_width > max_width){
this.signError=' * The width of the photograph should be 160 pixels.'+
'Width of your photo is'+img_width +'Pixel.';
return false;}
else {
const signBase64Path = e.target.result;
this.cardSignBase64 = signBase64Path;
this.isSignSaved = true;}
};};
reader1.readAsDataURL(fileInput1.target.files[0]);}}

  removeImage() {
    this.cardImage1Base64 = null;
    this.isImage1Saved = false;
}
removeSign(){
    this.cardSignBase64 = null;
    this.isSignSaved = false;
}
//Errors//


//category and coursee

category = new FormControl('',[Validators.required])
courses = new FormControl('',[Validators.required])
//personal
fullname = new FormControl('', [Validators.required]);
mothername = new FormControl('', [Validators.required,]);
dob = new FormControl('',[Validators.required]);
firstname = new FormControl('', [Validators.required]);
gender = new FormControl('',[Validators.required]);
nationality = new FormControl('',[Validators.required]);
mstatus = new FormControl('',[Validators.required]);
religion = new FormControl('',[Validators.required]);
number = new FormControl('',[Validators.required, Validators.minLength(10), Validators.maxLength(10)]);
email = new FormControl('', [Validators.required, Validators.email]);
Aadhar = new FormControl('',[Validators.required,Validators.minLength(12),Validators.maxLength(12)]);
pob = new FormControl('',[Validators.required]);
ca = new FormControl('',[Validators.required]);
income= new FormControl('',[Validators.required]);
motherfullname= new FormControl('',[Validators.required]);
fatherfullname= new FormControl('',[Validators.required]);

 //ssc
 boarduniversity= new FormControl('',[Validators.required,]);
 schoolcollege= new FormControl('',[Validators.required, ]);
 moo=  new FormControl('',[Validators.required,]);
 percentage= new FormControl('',[Validators.required]);
 passing= new FormControl('',[Validators.required ]);
 mo=  new FormControl('',[Validators.required ]);
 seatrollno = new FormControl('',[Validators.required]);
 //hsc
 boarduniversity1= new FormControl('',[Validators.required,]);
 schoolcollege1= new FormControl('',[Validators.required, ]);
 moo1=  new FormControl('',[Validators.required,]);
 percentage1= new FormControl('',[Validators.required]);
 passing1= new FormControl('',[Validators.required ]);
 mo1=  new FormControl('',[Validators.required ]);
 seatrollno1 = new FormControl('',[Validators.required]);

//Graduation//

 //Sem 1
 boarduniversity2= new FormControl('',[Validators.required,]);
 schoolcollege2= new FormControl('',[Validators.required, ]);
 moo2=  new FormControl('',[Validators.required,]);
 percentage2= new FormControl('',[Validators.required]);
 passing2= new FormControl('',[Validators.required ]);
 mo2=  new FormControl('',[Validators.required ]);
 seatrollno2 = new FormControl('',[Validators.required]);

 //Sem 2
 boarduniversity3= new FormControl('',[Validators.required,]);
 schoolcollege3= new FormControl('',[Validators.required, ]);
 moo3=  new FormControl('',[Validators.required,]);
 percentage3= new FormControl('',[Validators.required]);
 passing3= new FormControl('',[Validators.required ]);
 mo3=  new FormControl('',[Validators.required ]);
 seatrollno3 = new FormControl('',[Validators.required]);
 
 //docs upload
 Aadhar1= new FormControl('',[Validators.required,]);
Rationcard= new FormControl('',[Validators.required,]);
sem1= new FormControl('',[Validators.required,]);
sem= new FormControl('',[Validators.required,]);

//verification
check = new FormControl('',[Validators.required]);
  photo = new FormControl('',[Validators.required]);
  sign = new FormControl('',[Validators.required]);
  
}

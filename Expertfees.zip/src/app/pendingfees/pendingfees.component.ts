import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingfees',
  templateUrl: './pendingfees.component.html',
  styleUrls: ['./pendingfees.component.css']
})
export class PendingfeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

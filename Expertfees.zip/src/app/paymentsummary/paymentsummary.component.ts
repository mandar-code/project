import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'paymentsummary',
  templateUrl: './paymentsummary.component.html',
  styleUrls: ['./paymentsummary.component.css']
})
export class PaymentsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

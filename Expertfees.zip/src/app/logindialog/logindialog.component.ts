import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logindialog',
  templateUrl: './logindialog.component.html',
  styleUrls: ['./logindialog.component.css']
})
export class LogindialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

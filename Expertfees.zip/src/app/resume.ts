export class Resume {
    fullname: string;
    mothername:string;
    dob:number;
    firstname:string;
    middlename:string;
    lastname:string;
    gender: string;
    maritalstatus:string;
    pob:string;

}
   
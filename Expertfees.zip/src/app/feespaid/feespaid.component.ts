import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'feespaid',
  templateUrl: './feespaid.component.html',
  styleUrls: ['./feespaid.component.css']
})
export class FeespaidComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

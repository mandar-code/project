
import { Component, OnInit } from '@angular/core';
import '@vaadin/vaadin-button';
import '@vaadin/vaadin-grid';
import '@vaadin/vaadin-text-field';
import '@vaadin/vaadin-icons';
import '@vaadin/vaadin-list-box';
import '@vaadin/vaadin-overlay';
import '@vaadin/vaadin-combo-box';
import '@vaadin/vaadin-date-picker';
import '@vaadin/vaadin-dialog';
import '@vaadin/vaadin-form-layout';
import '@vaadin/vaadin-login';
import '@vaadin/vaadin-menu-bar';
import '@vaadin/vaadin-select';
import '@vaadin/vaadin-tabs';
import '@vaadin/vaadin-upload';
import '@vaadin/vaadin-app-layout';
import '@vaadin/vaadin-accordion';
import '@vaadin/vaadin-checkbox';
import '@vaadin/vaadin-lumo-styles';
import '@vaadin/vaadin-radio-button';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {

   constructor(){
  }

  ngOnInit(){
    
  }
}
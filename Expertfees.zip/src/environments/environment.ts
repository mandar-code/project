// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
       
        firebaseConfig:{
       
       apiKey: "AIzaSyAiw7PM_MtdPzD_rLANXMT-ynf2CvrCsWw",
      authDomain: "expert-fees-9be54.firebaseapp.com",
      databaseURL: "https://expert-fees-9be54.firebaseio.com",
      projectId: "expert-fees-9be54",
      storageBucket: "expert-fees-9be54.appspot.com",
      messagingSenderId: "603662476776",
      appId: "1:603662476776:web:1ec84bc78447fac7da705d",
      measurementId: "G-1KEMGL0QZF"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
